// AJG23055 牧野唯希

extern int n;

double length(double vector[]);
void unit_vector(double vector[], double unit_vector[]);
double naiseki(double vector1[], double vector2[]);
double henkaku(double vector1[], double vector2[]);
